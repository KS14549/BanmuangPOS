#include "PriceDelegate.h"
#include <QDoubleSpinBox>
#include <QMessageBox>

PriceDelegate::PriceDelegate(QStandardItemModel *productModel, QObject *parent)
    : QStyledItemDelegate(parent),
    m_productModel(productModel)
{}

QWidget *PriceDelegate::createEditor(QWidget *parent,
                                     const QStyleOptionViewItem &,
                                     const QModelIndex &) const
{
    QDoubleSpinBox *editor = new QDoubleSpinBox(parent);
    editor->setDecimals(2);
    editor->setMinimum(0.00);
    editor->setMaximum(999999.99);
    return editor;
}

void PriceDelegate::setModelData(QWidget *editor,
                                 QAbstractItemModel *model,
                                 const QModelIndex &index) const
{
    QDoubleSpinBox *spinBox = qobject_cast<QDoubleSpinBox*>(editor);
    double newPrice = spinBox->value();

    // === Get barcode from the same row in the cart ===
    QString barcode = model->index(index.row(), 1).data().toString();

    // === Find the matching cost price from product table ===
    double costPrice = 0.0;
    if (m_productModel) {
        for (int i = 0; i < m_productModel->rowCount(); ++i) {
            if (m_productModel->item(i, 0)->text() == barcode) {
                costPrice = m_productModel->item(i, 4)->text().toDouble(); // column 4 = cost price
                break;
            }
        }
    }

    // === Validate ===
    if (newPrice < costPrice && costPrice > 0) {
        QMessageBox::warning(nullptr,
                             QObject::tr("ราคาขายไม่ถูกต้อง"),
                             QObject::tr("ราคาขาย (%1) ต้องไม่ต่ำกว่าราคาทุน (%2)")
                                 .arg(newPrice, 0, 'f', 2)
                                 .arg(costPrice, 0, 'f', 2));

        spinBox->setValue(costPrice);
        newPrice = costPrice;
    }

    model->setData(index, QString::number(newPrice, 'f', 2));
}
