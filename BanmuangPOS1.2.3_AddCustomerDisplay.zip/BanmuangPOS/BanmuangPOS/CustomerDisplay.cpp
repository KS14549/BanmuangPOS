#include "CustomerDisplay.h"
#include <QVBoxLayout>
#include <QHeaderView>

CustomerDisplay::CustomerDisplay(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("Customer Display");
    setWindowFlags(Qt::FramelessWindowHint); // POS style

    tableView = new QTableView(this);
    tableView->setSelectionMode(QAbstractItemView::NoSelection);
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableView->verticalHeader()->hide();
    tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tableView->setFont(QFont("Segoe UI", 18));

    auto *layout = new QVBoxLayout(this);
    layout->addWidget(tableView);
    setLayout(layout);
}

void CustomerDisplay::setModel(QAbstractItemModel *model)
{
    tableView->setModel(model);

    // ซ่อนคอลัมน์ที่ลูกค้าไม่ต้องเห็น
    tableView->hideColumn(1); // barcode
}
