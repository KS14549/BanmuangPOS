QT       += core gui sql printsupport

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    CustomerDisplay.cpp \
    Database.cpp \
    PaymentDialog.cpp \
    PriceDelegate.cpp \
    main.cpp \
    mainwindow.cpp

HEADERS += \
    CartModel.h \
    CustomerDisplay.h \
    Database.h \
    PaymentDialog.h \
    PriceDelegate.h \
    QuantityDelegate.h \
    mainwindow.h

FORMS += \
    mainwindow.ui \
    paymentdialog.ui

TRANSLATIONS += \
    BanmuangPOS_en_US.ts
CONFIG += lrelease
CONFIG += embed_translations

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
