#ifndef CUSTOMERDISPLAY_H
#define CUSTOMERDISPLAY_H

#include <QWidget>
#include <QTableView>

class CustomerDisplay : public QWidget {
    Q_OBJECT
public:
    explicit CustomerDisplay(QWidget *parent = nullptr);

    void setModel(QAbstractItemModel *model);

private:
    QTableView *tableView;
};


#endif // CUSTOMERDISPLAY_H
