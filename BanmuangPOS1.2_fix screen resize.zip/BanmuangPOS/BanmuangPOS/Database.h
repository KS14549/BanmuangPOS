#ifndef DATABASE_H
#define DATABASE_H


#include <QSqlDatabase>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QSqlError>
#include <QDebug>

class Database {
public:
    // Constructor (คอนสตรัคเตอร์) คือเมธอดพิเศษในภาษาโปรแกรมเชิงวัตถุ (Object-Oriented Programming หรือ OOP) ที่ถูกเรียกใช้โดยอัตโนมัติเมื่อมีการสร้างวัตถุ (Object) จากคลาส เพื่อกำหนดค่าเริ่มต้นให้กับวัตถุนั้นๆ
    Database(QString path);
    // Destructor
    ~Database();

    bool openConnection();
    void closeConnection();

    //Set Query Method
    QStringList executeQuery(QString tableName);
    QList<QList<QString>> executeDetailedQuery(const QString& tableName);
    void setCategoryID(int id);

private:
    QString dbPath;
    QSqlDatabase sqlDatabase;
    int categoryID;
};

#endif // DATABASE_H
