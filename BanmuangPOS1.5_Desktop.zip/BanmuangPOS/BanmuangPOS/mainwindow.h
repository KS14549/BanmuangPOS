#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QTableView>
#include <QPushButton>
#include <QMenu>
#include <QMessageBox>
#include <QDebug>
#include <QMap>
#include <QHeaderView>
#include <QFont>
#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QPoint>

#include "Database.h"   // your custom database class


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // === UI Setup Functions ===
    void setupTables();
    void setupDeliveryUI();
    void setupCategoryButtons();

    // === Product Loading & Interaction ===
    void loadProducts(int categoryID);
    void onTableRowClicked(const QModelIndex &index);

    // === Cart Interaction ===
    void onCartContextMenu(const QPoint &pos);
    void onCartItemChanged(QStandardItem *item);
    double updateTotalPrice();
    void on_actionPayment_triggered();

    // menu
    void updateCostPrice();
    void updateSellingPrice();
    void printBill(double received, double change);
    void setCustomerID();

private:
    Ui::MainWindow *ui;

    QStandardItemModel *tableModel;   // Product table
    QStandardItemModel *cartModel;    // Cart table

    Database BMdatabase;            // Your custom database connection

    bool updatingCart;                // Prevents recursive updates
    QString customerID;
};

#endif // MAINWINDOW_H
