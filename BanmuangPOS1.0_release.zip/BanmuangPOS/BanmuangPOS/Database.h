#ifndef DATABASE_H
#define DATABASE_H

#include <QString>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>

// ✅ Product struct with both cost and selling price
struct Product {
    QString barcode;
    QString name;
    QString detail;
    QString unit;
    double costPrice;
    double sellingPrice;
};
struct Customer {
    QString customerName;
    QString customerEmployee;
    QString customerPhone;
    QString customerAddress;
};

class Database {
public:
    explicit Database(const QString &path);
    ~Database();

    bool openConnection();
    void closeConnection();
    bool isOpen() const;

    QList<Product> getProductsByCategory(const QString &tableName, int categoryID);

    // ✅ Get access to the database object
    QSqlDatabase& getDatabase();

    // ✅ Helper: update product price (either cost or selling)
    bool updatePrice(const QString &barcode, double newPrice, bool isSellingPrice);
    Product findProductByName(const QString& name);
    Customer findCustomerByID(const int& customerID);

private:
    QString dbPath;
    QSqlDatabase sqlDatabase;
};

#endif // DATABASE_H
