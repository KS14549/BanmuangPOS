#ifndef CARTMODEL_H
#define CARTMODEL_H

#include <QStandardItemModel>

class CartModel : public QStandardItemModel {
    Q_OBJECT
public:
    explicit CartModel(QObject *parent = nullptr)
        : QStandardItemModel(parent) {}

    Qt::ItemFlags flags(const QModelIndex &index) const override {
        Qt::ItemFlags defaultFlags = QStandardItemModel::flags(index);
        if (!index.isValid())
            return Qt::NoItemFlags;

        // Only allow editing for "จำนวน" column (6)
        if (index.column() == 5 || index.column() == 6)
            return defaultFlags | Qt::ItemIsEditable;
        else
            return defaultFlags & ~Qt::ItemIsEditable;
    }
};

#endif // CARTMODEL_H
