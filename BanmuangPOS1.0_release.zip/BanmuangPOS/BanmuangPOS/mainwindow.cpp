#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CartModel.h"
#include "PriceDelegate.h"
#include "QuantityDelegate.h"
#include "PaymentDialog.h"



#include <QInputDialog>
#include <QMessageBox>
#include <QScreen>
#include <QSettings>
#include <QPrinter>
#include <QPainter>
#include <QTextDocument>
#include <QTextOption>
#include <QDesktopServices>
#include <QDir>
#include <QUrl>
#include <QStandardPaths>
#include <QProcess>
#include <QDateTime>
#include <QPageSize>
#include <QPageLayout>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , tableModel(new QStandardItemModel(this))
    , cartModel(new CartModel(this))
    , BMdatabase("Banmuang.db")
    , updatingCart(false)
{
    ui->setupUi(this);
    this->resize(1366,768);
    this->showNormal();

    // === Menu Bar ===
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);

    QMenu *menuActions = menuBar->addMenu(tr("เมนู"));
    QAction *actionAddProductToCart = menuActions->addAction(tr("เพิ่มสินค้าลงตระกร้า"));
    QAction *actionUpdateCostPrice = menuActions->addAction(tr("อัปเดตราคาต้นทุน"));
    QAction *actionUpdateSellingPrice = menuActions->addAction(tr("อัปเดตราคาขาย"));
    QAction *actionPayment = menuActions->addAction(tr("ชำระเงิน"));
    QAction *actionCustomerID = menuActions->addAction(tr("ระบุรหัสลูกค้า (จัดส่ง)"));


    // Connect actions
    connect(actionAddProductToCart, &QAction::triggered, this, &MainWindow::addProductToCartByName);
    connect(actionUpdateCostPrice, &QAction::triggered, this, &MainWindow::updateCostPrice);
    connect(actionUpdateSellingPrice, &QAction::triggered, this, &MainWindow::updateSellingPrice);
    connect(actionPayment, &QAction::triggered, this, &MainWindow::on_actionPayment_triggered);
    connect(actionCustomerID, &QAction::triggered, this, &MainWindow::setCustomerID);
    actionAddProductToCart->setShortcut(QKeySequence(Qt::Key_F1));
    actionUpdateCostPrice->setShortcut(QKeySequence(Qt::Key_F3));
    actionUpdateSellingPrice->setShortcut(QKeySequence(Qt::Key_F4));
    actionPayment->setShortcut(QKeySequence(Qt::Key_F8));
    actionCustomerID->setShortcut(QKeySequence(Qt::Key_F10));

    connect(ui->pushButton_OK, &QPushButton::clicked, this, &MainWindow::on_actionPayment_triggered);

    // === Open Database ===
    if (!BMdatabase.openConnection()) {
        QMessageBox::critical(this, tr("Database Error"),
                              tr("ไม่สามารถเปิดฐานข้อมูล Banmuang.db ได้"));
        return;
    }
    qDebug() << "✅ Database opened successfully.";

    setupTables();
    setupCategoryButtons();
    setupDeliveryUI();

    // Load default category
    loadProducts(1);
}

MainWindow::~MainWindow() {
    BMdatabase.closeConnection();
    delete ui;
}

// === Setup Product & Cart Tables ===
void MainWindow::setupTables() {
    // === Product Table ===
    tableModel->setHorizontalHeaderLabels(
        {"รหัสบาร์โค้ด", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาต้นทุน", "ราคาขายต่อหน่วย"}
        );

    auto *table = ui->tableView;
    table->setModel(tableModel);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setAlternatingRowColors(true);
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    table->verticalHeader()->hide();

    table->setColumnWidth(0, 60);  // Barcode
    table->setColumnWidth(1, 180);  // Product Name
    table->setColumnWidth(2, 180);  // Product Detail
    table->setColumnWidth(3, 40);   // Unit
    table->setColumnWidth(4, 80);  // Cost Price
    table->setColumnWidth(5, 80);  // Selling Price
    connect(table, &QTableView::clicked, this, &MainWindow::onTableRowClicked);

    // === Cart Table ===
    cartModel->setHorizontalHeaderLabels(
        {"#", "รหัสสินค้า", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาขายต่อหน่วย", "จำนวน"}
        );

    auto *cart = ui->tableView_2;
    cart->setModel(cartModel);
    cart->setItemDelegateForColumn(5, new PriceDelegate(this));     // price (double)
    cart->setItemDelegateForColumn(6, new QuantityDelegate(this));  // quantity (int)
    cart->setSelectionBehavior(QAbstractItemView::SelectRows);
    cart->setSelectionMode(QAbstractItemView::SingleSelection);
    cart->setAlternatingRowColors(true);
    cart->verticalHeader()->hide();
    cart->setEditTriggers(QAbstractItemView::AllEditTriggers);
    cart->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    cart->setFont(QFont("Segoe UI", 12));

    cart->setColumnWidth(0, 20);// Row number
    cart->setColumnWidth(1, 40);// Barcode
    cart->setColumnWidth(2, 180);// ProductName
    cart->setColumnWidth(3, 180);// ProcuctDetail
    cart->setColumnWidth(4, 40);// Unit
    cart->setColumnWidth(5, 80);// SellingPrice
    cart->setColumnWidth(6, 80); //QTY



    // Context Menu
    cart->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(cart, &QTableView::customContextMenuRequested,
            this, &MainWindow::onCartContextMenu);

    connect(cartModel, &QStandardItemModel::itemChanged,
            this, &MainWindow::onCartItemChanged);
}

// === Delivery UI Setup ===
void MainWindow::setupDeliveryUI() {
    ui->doubleSpinBox_deliveryFee->setEnabled(false);

    connect(ui->checkBox_delivery, &QCheckBox::toggled, this, [this](bool checked) {
        ui->doubleSpinBox_deliveryFee->setEnabled(checked);
        updateTotalPrice();
    });

    connect(ui->doubleSpinBox_deliveryFee, qOverload<double>(&QDoubleSpinBox::valueChanged),
            this, &MainWindow::updateTotalPrice);
}

// === Map Category Buttons ===
void MainWindow::setupCategoryButtons() {
    const QMap<QString, int> buttonCategoryMap = {
        {"cPushButton_1", 1}, {"cPushButton_2", 2}, {"cPushButton_3", 3},
        {"cPushButton_4", 4}, {"cPushButton_5", 5}, {"cPushButton_6", 6},
        {"cPushButton_7", 7}, {"cPushButton_8", 8}, {"cPushButton_9", 9},
        {"cPushButton_10", 10}, {"cPushButton_11", 11}, {"cPushButton_12", 12},
        {"cPushButton_13", 13}, {"cPushButton_14", 14}, {"cPushButton_15", 15},
        {"cPushButton_16", 16}, {"cPushButton_17", 17}, {"cPushButton_18", 18},
        {"cPushButton_19", 19}, {"cPushButton_20", 20}
    };

    for (auto it = buttonCategoryMap.constBegin(); it != buttonCategoryMap.constEnd(); ++it) {
        if (auto *btn = findChild<QPushButton *>(it.key())) {
            connect(btn, &QPushButton::clicked, this, [this, categoryID = it.value()] {
                loadProducts(categoryID);
            });
        } else {
            qWarning() << "⚠️ Button not found:" << it.key();
        }
    }
}

// === Load Products by Category ===
void MainWindow::loadProducts(int categoryID) {
    qDebug() << "Loading products for category ID:" << categoryID;
    const QList<Product> products = BMdatabase.getProductsByCategory("Products", categoryID);

    tableModel->removeRows(0, tableModel->rowCount());

    for (const Product &p : products) {
        QList<QStandardItem *> rowItems;
        rowItems << new QStandardItem(p.barcode)
                 << new QStandardItem(p.name)
                 << new QStandardItem(p.detail)
                 << new QStandardItem(p.unit)
                 << new QStandardItem(QString::number(p.costPrice, 'f', 2))
                 << new QStandardItem(QString::number(p.sellingPrice, 'f', 2));
        tableModel->appendRow(rowItems);
    }
}

// === Add product to cart ===
void MainWindow::onTableRowClicked(const QModelIndex &index) {
    if (!index.isValid()) return;

    const int row = index.row();
    const QString barcode = tableModel->item(row, 0)->text();
    const QString name = tableModel->item(row, 1)->text();
    const QString detail = tableModel->item(row, 2)->text();
    const QString unit = tableModel->item(row, 3)->text();
    const QString costPrice = tableModel->item(row, 4)->text();
    const QString sellingPrice = tableModel->item(row, 5)->text();

    // Check if product already exists in cart
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        if (cartModel->item(i, 1)->text() == barcode) {
            // Increase quantity safely
            int qty = cartModel->item(i, 6)->text().toInt();
            cartModel->item(i, 6)->setText(QString::number(qty + 1));
            return;
        }
    }

    // Add new row to cart
    QList<QStandardItem *> newRow = {
        new QStandardItem(QString::number(cartModel->rowCount() + 1)),
        new QStandardItem(barcode),
        new QStandardItem(name),
        new QStandardItem(detail),
        new QStandardItem(unit),
        new QStandardItem(sellingPrice),
        new QStandardItem("1")
    };
    cartModel->appendRow(newRow);
    updateTotalPrice();
}

// === Context Menu (Remove item) ===
void MainWindow::onCartContextMenu(const QPoint &pos) {
    QModelIndex index = ui->tableView_2->indexAt(pos);
    if (!index.isValid()) return;

    QMenu menu;
    QAction *removeAction = menu.addAction(tr("ลบสินค้า"));
    QAction *selected = menu.exec(ui->tableView_2->viewport()->mapToGlobal(pos));

    if (selected == removeAction) {
        cartModel->removeRow(index.row());

        // Reindex rows
        for (int i = 0; i < cartModel->rowCount(); ++i)
            cartModel->item(i, 0)->setText(QString::number(i + 1));

        updateTotalPrice();
    }
}

// === Quantity Changed (Guarded) ===
void MainWindow::onCartItemChanged(QStandardItem *item) {
    if (updatingCart || !item) return;
    if (item->column() == 5 || item->column() == 6)
        updateTotalPrice();
}

// === Calculate Total ===
double MainWindow::updateTotalPrice() {
    updatingCart = true;

    double total = 0.0;
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        if (qty < 1) {
            cartModel->item(i, 6)->setText("1");
            qty = 1;
        }
        total += price * qty;
    }

    if (ui->checkBox_delivery->isChecked()) {
        total += ui->doubleSpinBox_deliveryFee->value();
    }

    ui->label_totalPrice->setText(QString("รวมทั้งหมด: %1 บาท").arg(total, 0, 'f', 2));

    updatingCart = false;
    return total;
}

// === Update product prices in cart ===
void MainWindow::updateCostPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 4)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาต้นทุน"),
        tr("ราคาต้นทุนใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, false)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาต้นทุนได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 4)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}

void MainWindow::updateSellingPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 5)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาขาย"),
        tr("ราคาขายใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, true)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาขายได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 5)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}



// === Print Bill ===
void MainWindow::printBill(double received, double change)
{
    // QString dateTimeStr = QDateTime::currentDateTime().toString("dd/MM/yyyy HH:mm:ss");
    QString dateTimeStr = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh:mm:ss");
    QString desktopPath = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString receiptFolderPath = QDir(desktopPath).filePath("Receipt");
    QDir().mkpath(receiptFolderPath);  // ✅ auto create folder if missing

    QString posPath = QDir(receiptFolderPath).filePath(QString("Pos_%1.pdf").arg(dateTimeStr));
    QString billPath = QDir(receiptFolderPath).filePath(QString("Bill_%1.pdf").arg(dateTimeStr));
    QString notePath    = QDir(receiptFolderPath).filePath(QString("Delivery_%1.pdf").arg(dateTimeStr));

    QPrinter printerPos(QPrinter::HighResolution);
    QPrinter printerBill(QPrinter::HighResolution);
    QPrinter printerNote(QPrinter::HighResolution);

    printerPos.setOutputFormat(QPrinter::PdfFormat);
    printerBill.setOutputFormat(QPrinter::PdfFormat);
    printerNote.setOutputFormat(QPrinter::PdfFormat);

    printerPos.setOutputFileName(posPath);
    printerBill.setOutputFileName(billPath);
    printerNote.setOutputFileName(notePath);

    // POS font 10pt = 3.5mm, 80mm/3.5mm = 22Ch
    // A4 font 16pt = 5.6mm, 210/5.6 =37.5Ch
    printerPos.setPageSize(QPageSize(QSizeF(80, 100), QPageSize::Millimeter));
    printerBill.setPageSize(QPageSize(QPageSize::A4));
    printerNote.setPageSize(QPageSize(QPageSize::A4));

    printerPos.setPageMargins(QMarginsF( 1, 1, 1, 1), QPageLayout::Millimeter);
    printerPos.setFullPage(true);
    printerBill.setPageMargins(QMarginsF(10, 10, 10, 10));
    printerNote.setPageMargins(QMarginsF(10, 10, 10, 10));

    QString pos,bill,note;
    pos += "          BM          \n";
    bill += "                         ใบส่งของชั่วคราว                        \n";
    note += "                         ใบส่งของชั่วคราว                        \n";

    pos += QString("%1\n").arg(dateTimeStr,20);
    bill += QString("%1%2\n").arg("วันที่:",40).arg(dateTimeStr,20);
    note += QString("%1%2\n").arg("วันที่:",40).arg(dateTimeStr,20);

    QString nameStr,emStr,phoneStr,addressStr;
    bool ok = false;
    if(ui->checkBox_delivery->isChecked() && customerIDCheck == true){
        Customer customer = BMdatabase.findCustomerByID(customerID.toInt());
        nameStr = customer.customerName;
        emStr = customer.customerEmployee;
        phoneStr = customer.customerPhone;
        addressStr = customer.customerAddress;
    }else if(ui->checkBox_delivery->isChecked()){
        nameStr = QInputDialog::getText(
            this,
            tr("ชื่อลูกค้าที่ต้องการเพิ่ม"),
            tr("กรอกชื่อลูกค้า:"),
            QLineEdit::Normal,
            "",
            &ok
        );
        phoneStr = QInputDialog::getText(
            this,
            tr("เบอร์โทรที่ต้องการเพิ่ม"),
            tr("กรอกเบอร์โทร:"),
            QLineEdit::Normal,
            "",
            &ok
        );
    }

    bill += QString("ชื่อ: %1 เบอร์โทร: %2 \n").arg(nameStr+" "+emStr,-30).arg(phoneStr,-30);
    bill += QString("ที่อยู่ : %1 \n").arg(addressStr, -60);
    note += QString("ชื่อ: %1 เบอร์โทร: %2 \n").arg(nameStr,-30).arg(phoneStr,-30);
    note += QString("ที่อยู่ : %1 \n").arg(addressStr, -60);
    bill += "------------------------------------------------------------\n";
    note += "------------------------------------------------------------\n";

    pos += QString("%1%2%3\n")
                .arg("จำนวน", -3)
                .arg("หน่วย", -3)
                .arg("สินค้า", -10)
               .arg("ราคา/ชิ้น"),4;
    pos += "----------------------\n";
    bill += QString("%1%2%3%4%5\n")
                .arg("จำนวน", -8)
                .arg("หน่วย", -8)
                .arg("สินค้า", -24)
                .arg("ราคาต่อหน่วย", 10)
                .arg("รวม", 10);
    bill += "------------------------------------------------------------\n";
    note += QString("%1%2%3\n")
                .arg("จำนวน", -8)
                .arg("หน่วย", -8)
                .arg("สินค้า", -40);
    note += "------------------------------------------------------------\n";



    // === รายการสินค้า ===
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        QString name = cartModel->item(i, 2)->text();
        QString detail = cartModel->item(i, 3)->text();
        QString unit = cartModel->item(i, 4)->text();
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        double sum = price * qty;

        // Each line: จำนวน หน่วย สินค้า รวม
        pos += QString("%1%2%3%4\n")
                    .arg(QString::number(qty), -3)
                    .arg(unit, -3)
                    .arg(name + " " + detail.left(10),-10)
                    .arg(QString::number(price, 'f', 0), 4);
        bill += QString("%1%2%3%4%5\n")
                    .arg(QString::number(qty), -5)
                    .arg(unit, -5)
                    .arg(name+detail.left(30), -30)
                    .arg(QString::number(price, 'f', 2), 10)
                    .arg(QString::number(sum, 'f', 2), 10);
        note += QString("%1%2%3\n")
                    .arg(QString::number(qty), -8)
                    .arg(unit, -8)
                    .arg(name + " " + detail.left(40), -40);


    }

    pos += "----------------------\n";
    bill += "------------------------------------------------------------\n";
    note += "------------------------------------------------------------\n";
    note += "  ผู้รับสินค้า                                                   \n";
    note += "               (โปรดตรวจสอบจำนวนสินค้าก่อนรับของ)                 \n";



    if (ui->checkBox_delivery->isChecked()) {
        pos += QString("%1 %2 บาท\n")
                   .arg("ค่าจัดส่ง:", -10)
                   .arg(QString::number(ui->doubleSpinBox_deliveryFee->value(), 'f', 2), 10);
        bill += QString("%1 %2 บาท\n")
                    .arg("ค่าจัดส่ง:", 50)
                    .arg(QString::number(ui->doubleSpinBox_deliveryFee->value(), 'f', 2), 10);
    }

    double total = updateTotalPrice();
    pos += QString("%1 %2 บาท\n")
               .arg("รวมทั้งหมด:", -10)
               .arg(QString::number(total, 'f', 2), 10);
    bill += QString("%1 %2 บาท\n")
                .arg("รวมทั้งหมด:", 50)
                .arg(QString::number(total, 'f', 2), 10);
    pos += "----------------------\n";
    bill += "------------------------------------------------------------\n";
    if(customerIDCheck == false){
        pos += QString("%1 %2 บาท\n")
                   .arg("รับเงิน:", -10)
                   .arg(QString::number(received, 'f', 2), 10);
        bill += QString("%1 %2 บาท\n")
                    .arg("รับเงิน:", 50)
                    .arg(QString::number(received, 'f', 2), 10);
        pos += QString("%1 %2 บาท\n")
                   .arg("ทอนเงิน:", -10)
                   .arg(QString::number(change, 'f', 2), 10);
        bill += QString("%1 %2 บาท\n")
                    .arg("ทอนเงิน:", 50)
                    .arg(QString::number(change, 'f', 2), 10);

    }
    bill += "------------------------------------------------------------\n";
    bill += "                    ขอบคุณที่อุดหนุนครับ/ค่ะ                       \n";
    bill += "------------------------------------------------------------\n";



    // === Print to PDF ===
    QTextDocument docPos,docBill,docNote;
    docPos.setPlainText(pos);
    docBill.setPlainText(bill);
    docNote.setPlainText(note);
    docPos.setDefaultFont(QFont("Ubuntu", 10));
    docBill.setDefaultFont(QFont("Ubuntu", 16));
    docNote.setDefaultFont(QFont("Ubuntu", 16));
    docPos.print(&printerPos);
    docBill.print(&printerBill);
    docNote.print(&printerNote);


    // ✅ Open folder automatically
    // QDesktopServices::openUrl(QUrl::fromLocalFile(receiptFolderPath));

    // ✅ Optionally print directly via CUPS
    QString printerPosName = "Printer_POS-80";
    QString printerBillName = "EPSON_L3150_Series";
    QString printerNoteName = "EPSON_L3150_Series";

    // === Direct printer calls without /bin/sh ===
    if (ui->checkBox_1->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerPosName, posPath});
        qDebug() << "Printing POS to:" << printerPosName << "Exit code:" << exitCode;
    }

    if (ui->checkBox_2->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerBillName, billPath});
        qDebug() << "Printing BILL to:" << printerBillName << "Exit code:" << exitCode;
    }

    if (ui->checkBox_3->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerNoteName, notePath});
        qDebug() << "Printing NOTE to:" << printerNoteName << "Exit code:" << exitCode;
    }


    QMessageBox::information(this, tr("ใบเสร็จ"),
                             tr("พิมพ์ใบเสร็จเรียบร้อย: %1").arg(posPath));
    customerIDCheck = false;
}




// === Set Customer ID ===
void MainWindow::setCustomerID() {
    if (!ui->checkBox_delivery->isChecked()) {
        QMessageBox::warning(this, tr("ไม่สามารถระบุได้"),
                             tr("กรุณาเลือกตัวเลือก 'จัดส่ง' ก่อน"));
        return;
    }

    bool ok;
    QString id = QInputDialog::getText(this, tr("ระบุรหัสลูกค้า"),
                                       tr("รหัสลูกค้า:"), QLineEdit::Normal,
                                       customerID, &ok);
    if (ok && !id.trimmed().isEmpty()) {
        customerID = id.trimmed();
        QMessageBox::information(this, tr("สำเร็จ"),
                                 tr("ตั้งค่ารหัสลูกค้าเป็น: %1").arg(customerID));
        customerIDCheck = true;
    }
}

void MainWindow::on_actionPayment_triggered()
{
    double totalAmount = updateTotalPrice();

    if (totalAmount <= 0) {
        QMessageBox::warning(this, tr("ไม่มีสินค้า"), tr("กรุณาเพิ่มสินค้าในตะกร้าก่อนชำระเงิน"));
        return;
    }

    PaymentDialog paymentDialog(totalAmount, this);

    connect(&paymentDialog, &PaymentDialog::paymentAccepted, this,
            [this](double received, double change) {
                printBill(received, change);
            });

    if (paymentDialog.exec() == QDialog::Accepted) {
        cartModel->clear();
        ui->checkBox_delivery->setChecked(false);
        ui->doubleSpinBox_deliveryFee->setValue(0.0);
    }
}

void MainWindow::addProductToCartByName()
{
    bool ok = false;
    QString productName = QInputDialog::getText(
        this,
        tr("ชื่อสินค้าที่ต้องการเพิ่ม"),
        tr("กรอกชื่อสินค้า:"),
        QLineEdit::Normal,
        "",
        &ok
        );
    Product product = BMdatabase.findProductByName(productName);

    if (product.name.isEmpty()) {
        // Product not found — ask if user wants to add manually
        QMessageBox::StandardButton reply = QMessageBox::question(
            this,
            tr("ไม่พบสินค้า"),
            tr("ไม่พบสินค้า '%1' ในฐานข้อมูล\n\nคุณต้องการเพิ่มสินค้าใหม่นี้ลงในตะกร้าหรือไม่?")
                .arg(productName),
            QMessageBox::Yes | QMessageBox::No
            );

        if (reply == QMessageBox::No)
            return;

        // Ask for selling price
        double sellingPrice = QInputDialog::getDouble(
            this,
            tr("เพิ่มราคาขาย"),
            tr("กรอกราคาขายสำหรับสินค้า '%1':").arg(productName),
            0.0, 0.0, 999999.0, 2, &ok
            );

        if (!ok) return;

        // Optionally ask for unit
        QString unit = QInputDialog::getText(
            this,
            tr("หน่วยสินค้า"),
            tr("กรอกหน่วยสำหรับสินค้า '%1' (เช่น ชิ้น, กล่อง, กิโล):").arg(productName),
            QLineEdit::Normal,
            "ชิ้น",
            &ok
            );
        if (!ok || unit.trimmed().isEmpty()) unit = "ชิ้น";

        // Add the product to cart only (not database)
        QList<QStandardItem*> newRow = {
            new QStandardItem(QString::number(cartModel->rowCount() + 1)),
            new QStandardItem("N/A"),                  // No barcode
            new QStandardItem(productName),            // Name
            new QStandardItem("สินค้าเพิ่มเอง"),      // Detail
            new QStandardItem(unit),                   // Unit
            new QStandardItem(QString::number(sellingPrice, 'f', 2)),  // Price
            new QStandardItem("1")                     // Quantity
        };

        cartModel->appendRow(newRow);
        updateTotalPrice();
        return;
    }

    // ✅ Product found — add normally
    QList<QStandardItem*> newRow = {
        new QStandardItem(QString::number(cartModel->rowCount() + 1)),
        new QStandardItem(product.barcode),
        new QStandardItem(product.name),
        new QStandardItem(product.detail),
        new QStandardItem(product.unit),
        new QStandardItem(QString::number(product.sellingPrice, 'f', 2)),
        new QStandardItem("1")
    };

    cartModel->appendRow(newRow);
    updateTotalPrice();
}




