#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CartModel.h"
#include "spinboxdelegate.h"

#include <QInputDialog>
#include <QMessageBox>
#include <QPrinter>
#include <QTextDocument>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , tableModel(new QStandardItemModel(this))
    , cartModel(new CartModel(this))
    , BMdatabase("Banmuang.db")
    , updatingCart(false)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->centralwidget);

    // === Menu Bar ===
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);

    QMenu *menuActions = menuBar->addMenu(tr("เมนู"));

    QAction *actionUpdateCostPrice = menuActions->addAction(tr("อัปเดตราคาต้นทุน"));
    QAction *actionUpdateSellingPrice = menuActions->addAction(tr("อัปเดตราคาขาย"));
    QAction *actionPrintBill = menuActions->addAction(tr("พิมพ์ใบเสร็จ"));
    QAction *actionCustomerID = menuActions->addAction(tr("ระบุรหัสลูกค้า (จัดส่ง)"));

    // Connect actions
    connect(actionUpdateCostPrice, &QAction::triggered, this, &MainWindow::updateCostPrice);
    connect(actionUpdateSellingPrice, &QAction::triggered, this, &MainWindow::updateSellingPrice);
    connect(actionPrintBill, &QAction::triggered, this, &MainWindow::printBill);
    connect(actionCustomerID, &QAction::triggered, this, &MainWindow::setCustomerID);


    // === Open Database ===
    if (!BMdatabase.openConnection()) {
        QMessageBox::critical(this, tr("Database Error"),
                              tr("ไม่สามารถเปิดฐานข้อมูล Banmuang.db ได้"));
        return;
    }
    qDebug() << "✅ Database opened successfully.";

    setupTables();
    setupCategoryButtons();
    setupDeliveryUI();

    // Load default category
    loadProducts(1);
}

MainWindow::~MainWindow() {
    BMdatabase.closeConnection();
    delete ui;
}

// === Setup Product & Cart Tables ===
void MainWindow::setupTables() {
    // === Product Table ===
    tableModel->setHorizontalHeaderLabels(
        {"รหัสบาร์โค้ด", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาต้นทุน", "ราคาขายต่อหน่วย"}
        );

    auto *table = ui->tableView;
    table->setModel(tableModel);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setAlternatingRowColors(true);
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->verticalHeader()->hide();
    connect(table, &QTableView::clicked, this, &MainWindow::onTableRowClicked);

    // === Cart Table ===
    cartModel->setHorizontalHeaderLabels(
        {"#", "รหัสสินค้า", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาขายต่อหน่วย", "จำนวน"}
        );

    auto *cart = ui->tableView_2;
    cart->setModel(cartModel);
    cart->setItemDelegateForColumn(6, new SpinBoxDelegate(this));
    cart->setSelectionBehavior(QAbstractItemView::SelectRows);
    cart->setSelectionMode(QAbstractItemView::SingleSelection);
    cart->setAlternatingRowColors(true);
    cart->verticalHeader()->hide();
    cart->setEditTriggers(QAbstractItemView::AllEditTriggers);
    cart->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    cart->verticalHeader()->setDefaultSectionSize(40);
    cart->setFont(QFont("Segoe UI", 12));

    // Context Menu
    cart->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(cart, &QTableView::customContextMenuRequested,
            this, &MainWindow::onCartContextMenu);

    connect(cartModel, &QStandardItemModel::itemChanged,
            this, &MainWindow::onCartItemChanged);
}

// === Delivery UI Setup ===
void MainWindow::setupDeliveryUI() {
    ui->doubleSpinBox_deliveryFee->setEnabled(false);

    connect(ui->checkBox_delivery, &QCheckBox::toggled, this, [this](bool checked) {
        ui->doubleSpinBox_deliveryFee->setEnabled(checked);
        updateTotalPrice();
    });

    connect(ui->doubleSpinBox_deliveryFee, qOverload<double>(&QDoubleSpinBox::valueChanged),
            this, &MainWindow::updateTotalPrice);
}

// === Map Category Buttons ===
void MainWindow::setupCategoryButtons() {
    const QMap<QString, int> buttonCategoryMap = {
        {"cPushButton_1", 1}, {"cPushButton_2", 2}, {"cPushButton_3", 3},
        {"cPushButton_4", 4}, {"cPushButton_5", 5}, {"cPushButton_6", 6},
        {"cPushButton_7", 7}, {"cPushButton_8", 8}, {"cPushButton_9", 9},
        {"cPushButton_10", 10}, {"cPushButton_11", 11}, {"cPushButton_12", 12},
        {"cPushButton_13", 13}, {"cPushButton_14", 14}, {"cPushButton_15", 15}
    };

    for (auto it = buttonCategoryMap.constBegin(); it != buttonCategoryMap.constEnd(); ++it) {
        if (auto *btn = findChild<QPushButton *>(it.key())) {
            btn->setMinimumSize(160, 80);
            btn->setStyleSheet("font-size: 18px; font-weight: bold;");
            connect(btn, &QPushButton::clicked, this, [this, categoryID = it.value()] {
                loadProducts(categoryID);
            });
        } else {
            qWarning() << "⚠️ Button not found:" << it.key();
        }
    }
}

// === Load Products by Category ===
void MainWindow::loadProducts(int categoryID) {
    qDebug() << "Loading products for category ID:" << categoryID;
    const QList<Product> products = BMdatabase.getProductsByCategory("Products", categoryID);

    tableModel->removeRows(0, tableModel->rowCount());

    for (const Product &p : products) {
        QList<QStandardItem *> rowItems;
        rowItems << new QStandardItem(p.barcode)
                 << new QStandardItem(p.name)
                 << new QStandardItem(p.detail)
                 << new QStandardItem(p.unit)
                 << new QStandardItem(QString::number(p.costPrice, 'f', 2))
                 << new QStandardItem(QString::number(p.sellingPrice, 'f', 2));
        tableModel->appendRow(rowItems);
    }
}

// === Add product to cart ===
void MainWindow::onTableRowClicked(const QModelIndex &index) {
    if (!index.isValid()) return;

    const int row = index.row();
    const QString barcode = tableModel->item(row, 0)->text();
    const QString name = tableModel->item(row, 1)->text();
    const QString detail = tableModel->item(row, 2)->text();
    const QString unit = tableModel->item(row, 3)->text();
    const QString costPrice = tableModel->item(row, 4)->text();
    const QString sellingPrice = tableModel->item(row, 5)->text();

    // Check if product already exists in cart
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        if (cartModel->item(i, 1)->text() == barcode) {
            // Increase quantity safely
            int qty = cartModel->item(i, 6)->text().toInt();
            cartModel->item(i, 6)->setText(QString::number(qty + 1));
            updateTotalPrice();
            return;
        }
    }

    // Add new row to cart
    QList<QStandardItem *> newRow = {
        new QStandardItem(QString::number(cartModel->rowCount() + 1)),
        new QStandardItem(barcode),
        new QStandardItem(name),
        new QStandardItem(detail),
        new QStandardItem(unit),
        new QStandardItem(sellingPrice),
        new QStandardItem("1")
    };
    cartModel->appendRow(newRow);
    updateTotalPrice();
}

// === Context Menu (Remove item) ===
void MainWindow::onCartContextMenu(const QPoint &pos) {
    QModelIndex index = ui->tableView_2->indexAt(pos);
    if (!index.isValid()) return;

    QMenu menu;
    QAction *removeAction = menu.addAction(tr("ลบสินค้า"));
    QAction *selected = menu.exec(ui->tableView_2->viewport()->mapToGlobal(pos));

    if (selected == removeAction) {
        cartModel->removeRow(index.row());

        // Reindex rows
        for (int i = 0; i < cartModel->rowCount(); ++i)
            cartModel->item(i, 0)->setText(QString::number(i + 1));

        updateTotalPrice();
    }
}

// === Quantity Changed (Guarded) ===
void MainWindow::onCartItemChanged(QStandardItem *item) {
    if (updatingCart || !item || item->column() != 6) return;
    updateTotalPrice();
}

// === Calculate Total ===
void MainWindow::updateTotalPrice() {
    updatingCart = true;

    double total = 0.0;
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        if (qty < 1) {
            cartModel->item(i, 6)->setText("1");
            qty = 1;
        }
        total += price * qty;
    }

    if (ui->checkBox_delivery->isChecked()) {
        total += ui->doubleSpinBox_deliveryFee->value();
    }

    ui->label_totalPrice->setText(QString("รวมทั้งหมด: %1 บาท").arg(total, 0, 'f', 2));

    updatingCart = false;
}

// === Update product prices in cart ===
void MainWindow::updateCostPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 4)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาต้นทุน"),
        tr("ราคาต้นทุนใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, false)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาต้นทุนได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 4)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}

void MainWindow::updateSellingPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 5)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาขาย"),
        tr("ราคาขายใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, true)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาขายได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 5)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}



// === Print Bill ===
void MainWindow::printBill() {
    QString bill;
    bill += "=========== ใบเสร็จ ===========\n";
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        QString name = cartModel->item(i, 2)->text();
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        double sum = price * qty;
        bill += QString("%1 x%2 = %3 บาท\n")
                    .arg(name)
                    .arg(qty)
                    .arg(sum, 0, 'f', 2);
    }

    bill += "-------------------------------\n";
    bill += ui->label_totalPrice->text() + "\n";

    if (ui->checkBox_delivery->isChecked()) {
        bill += QString("จัดส่งให้ลูกค้า ID: %1\n").arg(customerID.isEmpty() ? "N/A" : customerID);
    }

    bill += "===============================\n";

    // Show in dialog
    // QMessageBox::information(this, tr("ใบเสร็จ"), bill);
    QTextDocument doc;
    doc.setPlainText(bill);

    QPrinter printer;
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName("receipt.pdf");
    doc.print(&printer);

    QMessageBox::information(this, tr("ใบเสร็จ"),
                             tr("พิมพ์ใบเสร็จเรียบร้อย (receipt.pdf)"));
}

// === Set Customer ID ===
void MainWindow::setCustomerID() {
    if (!ui->checkBox_delivery->isChecked()) {
        QMessageBox::warning(this, tr("ไม่สามารถระบุได้"),
                             tr("กรุณาเลือกตัวเลือก 'จัดส่ง' ก่อน"));
        return;
    }

    bool ok;
    QString id = QInputDialog::getText(this, tr("ระบุรหัสลูกค้า"),
                                       tr("รหัสลูกค้า:"), QLineEdit::Normal,
                                       customerID, &ok);
    if (ok && !id.trimmed().isEmpty()) {
        customerID = id.trimmed();
        QMessageBox::information(this, tr("สำเร็จ"),
                                 tr("ตั้งค่ารหัสลูกค้าเป็น: %1").arg(customerID));
    }
}

