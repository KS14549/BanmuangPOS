#include "Database.h"

Database::Database(const QString &path)
    : dbPath(path)
{
    qDebug() << "Database initialized with path:" << dbPath;
}

Database::~Database() {
    closeConnection();
    qDebug() << "Database object destroyed.";
}

bool Database::openConnection() {
    if (dbPath.isEmpty()) {
        qWarning() << "❌ Database path is empty!";
        return false;
    }

    // Reuse existing connection if it exists
    if (QSqlDatabase::contains("main_connection")) {
        sqlDatabase = QSqlDatabase::database("main_connection");
        qDebug() << "Reusing existing database connection.";
    } else {
        sqlDatabase = QSqlDatabase::addDatabase("QSQLITE", "main_connection");
        sqlDatabase.setDatabaseName(dbPath);
        qDebug() << "New database connection created.";
    }

    if (!sqlDatabase.open()) {
        qWarning() << "❌ Failed to open database:" << sqlDatabase.lastError().text();
        return false;
    }

    qDebug() << "✅ Database connection opened successfully.";
    return true;
}

void Database::closeConnection() {
    if (sqlDatabase.isOpen()) {
        sqlDatabase.close();
        qDebug() << "✅ Database closed successfully.";
    }
}

bool Database::isOpen() const {
    return sqlDatabase.isOpen();
}

QSqlDatabase& Database::getDatabase() {
    return sqlDatabase;
}

// ✅ Load products from a specific category
QList<Product> Database::getProductsByCategory(const QString &tableName, int categoryID) {
    QList<Product> productList;

    if (!isOpen()) {
        qWarning() << "❌ Database is not open!";
        return productList;
    }

    QSqlQuery query(sqlDatabase);

    QString sql = QString(
                      "SELECT product_barcode, product_name, product_detail, unit_of_measure, cost_price, selling_price "
                      "FROM %1 WHERE category_id = :categoryID;"
                      ).arg(tableName);

    query.prepare(sql);
    query.bindValue(":categoryID", categoryID);

    if (!query.exec()) {
        qWarning() << "❌ Query failed:" << query.lastError().text();
        qWarning() << "SQL:" << sql;
        return productList;
    }

    while (query.next()) {
        Product p;
        p.barcode = query.value("product_barcode").toString();
        p.name = query.value("product_name").toString();
        p.detail = query.value("product_detail").toString();
        p.unit = query.value("unit_of_measure").toString();
        p.costPrice = query.value("cost_price").toDouble();
        p.sellingPrice = query.value("selling_price").toDouble();

        productList.append(p);
    }

    qDebug() << "✅ Loaded" << productList.size() << "products from category" << categoryID;
    return productList;
}

// ✅ Helper: update cost or selling price
bool Database::updatePrice(const QString &barcode, double newPrice, bool isSellingPrice) {
    if (!isOpen()) {
        qWarning() << "❌ Cannot update price: database is not open!";
        return false;
    }

    QString column = isSellingPrice ? "selling_price" : "cost_price";

    QSqlQuery query(sqlDatabase);
    query.prepare(QString("UPDATE Products SET %1 = :newPrice WHERE product_barcode = :barcode")
                      .arg(column));
    query.bindValue(":newPrice", newPrice);
    query.bindValue(":barcode", barcode);

    if (!query.exec()) {
        qWarning() << "❌ Failed to update" << column << "for barcode" << barcode
                   << ":" << query.lastError().text();
        return false;
    }

    qDebug() << "✅ Updated" << column << "for" << barcode << "to" << newPrice;
    return true;
}

