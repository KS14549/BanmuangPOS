#include "Database.h"

// Database::Database(const std::string& dbPath) : dbPath(dbPath), db(nullptr) {
Database::Database(QString path) : dbPath(path) {  // Constructor using a member initializer list
    // Initialization code

}

Database::~Database() {
    // Cleanup code
    closeConnection();
    qDebug() << "Database object destroyed";
}

bool Database::openConnection() {

    qDebug() << dbPath ;
    if (dbPath.isEmpty()) {
        qDebug() << "Database path is empty!";
        return false;
    }

    if (QSqlDatabase::contains("main_connection")) {
        sqlDatabase = QSqlDatabase::database("main_connection");
    } else {
        sqlDatabase = QSqlDatabase::addDatabase("QSQLITE", "main_connection");// Or QMYSQL, QPSQL, etc.
        sqlDatabase.setDatabaseName(dbPath);// set database name "/home/top14549/Banmuang.db"
        qDebug() << "Database connection opened:";
    }

    if (!sqlDatabase.open()) {
        qDebug() << "Database connection failed:" << sqlDatabase.lastError().text();
        return false;
    }
    return true;
}

void Database::closeConnection() {
    if (sqlDatabase.isOpen()) {
        sqlDatabase.close();
        qDebug() << "Database closed successfully";
    }
}

// Execute query based on current category ID
QList<QList<QString>> Database::executeDetailedQuery(const QString &tableName) {
    QList<QList<QString>> productRows;

    if (!sqlDatabase.isOpen()) {
        qDebug() << "Database is not open!";
        return productRows;
    }

    QSqlTableModel model(nullptr, sqlDatabase);
    model.setTable(tableName);
    model.setFilter("category_id = " + QString::number(categoryID));

    if (!model.select()) {
        qDebug() << "Query failed:" << model.lastError().text();
        return productRows;
    }

    for (int i = 0; i < model.rowCount(); ++i) {
        QSqlRecord record = model.record(i);
        QString barcode = record.value("product_barcode").toString();
        QString productName = record.value("product_name").toString();
        QString productDetail = record.value("product_detail").toString();
        QString sellingPrice = record.value("selling_price").toString();

        productRows.append({barcode, productName, productDetail, sellingPrice});
    }

    return productRows;
}

void Database::setCategoryID(int id){
    categoryID = id;
}
