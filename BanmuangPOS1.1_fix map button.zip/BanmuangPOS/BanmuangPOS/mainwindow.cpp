#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , BMdatabase("Banmuang.db")//Initialize the member Database object
    , tableModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    this->showNormal(); // or showFullScreen()

        // Try to open database
    if (!BMdatabase.openConnection()) {
        QMessageBox::critical(this, "Database Error", "Failed to open Banmuang.db");
        return;
    }

    // Set font for table view
    QFont tableFont;
    tableFont.setPointSize(16);
    ui->tableView->setFont(tableFont);

    // Configure the table model headers
    tableModel->setHorizontalHeaderLabels({"Barcode", "Product Name", "Product Detail", "Selling Price"});
    ui->tableView->setModel(tableModel);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers); // Read-only
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSortingEnabled(true);

    // Auto-resize columns
    QHeaderView *header = ui->tableView->horizontalHeader();
    header->setSectionResizeMode(0, QHeaderView::ResizeToContents); // Barcode
    header->setSectionResizeMode(1, QHeaderView::ResizeToContents); // Product Name
    header->setSectionResizeMode(2, QHeaderView::ResizeToContents); // Product Detail
    header->setSectionResizeMode(3, QHeaderView::ResizeToContents); // Selling Price

    // Optional: resize row height to fit content
    ui->tableView->resizeRowsToContents();

    // Connect table click
    connect(ui->tableView, &QTableView::clicked, this, &MainWindow::onTableRowClicked);

    // Connect all category buttons to a single slot
    QMap<QString, int> buttonCategoryMap = {
        {"cPushButton_1", 1}, // ทราย
        {"cPushButton_2", 2}, // หิน
        {"cPushButton_3", 3}, // ปูน
        {"cPushButton_4", 4}, // อิฐ
        {"cPushButton_5", 5}, // เสาเข็ม
        {"cPushButton_6", 6}, // แผ่น
        {"cPushButton_7", 7}, // เหล็ก
        {"cPushButton_8", 8}, // ถังวง
        {"cPushButton_9", 9}, // ตาข่าย
        {"cPushButton_10", 10} // หลังคา
    };

    for (auto it = buttonCategoryMap.begin(); it != buttonCategoryMap.end(); ++it) {
        QPushButton *btn = findChild<QPushButton *>(it.key());
        if (btn) {
            connect(btn, &QPushButton::clicked, this, [this, categoryID = it.value()] {
                BMdatabase.setCategoryID(categoryID);
                loadProducts();
            });
        }
    }

}

MainWindow::~MainWindow()
{
    BMdatabase.closeConnection();
    delete ui;
}

void MainWindow::loadProducts() {
    auto products = BMdatabase.executeDetailedQuery("Products");

    tableModel->removeRows(0, tableModel->rowCount());

    if (products.isEmpty()) {
        qDebug() << "No products found";
        return;
    }

    for (const QList<QString> &row : products) {
        QList<QStandardItem *> items;
        for (const QString &col : row) {
            items.append(new QStandardItem(col));
        }
        tableModel->appendRow(items);
    }

    ui->tableView->resizeRowsToContents();
}


// // SLOT: Called when a category button is clicked
// void MainWindow::onCategoryButtonClicked() {
//     QPushButton *button = qobject_cast<QPushButton *>(sender());
//     if (!button) return;

//     QRegularExpression re("cPushButton_(\\d+)");
//     QRegularExpressionMatch match = re.match(button->objectName());
//     if (match.hasMatch()) {
//         int categoryId = match.captured(1).toInt();
//         BMdatabase.setCategoryID(categoryId);
//         loadProducts();
//     }
// }

void MainWindow::onTableRowClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString productName = tableModel->item(row, 1)->text();
    QString productDetail = tableModel->item(row, 2)->text();
    QString price = tableModel->item(row, 3)->text();

    QMessageBox::information(this, "Product Selected",QString("Barcode: %1\nName: %2\nDetail: %3\nPrice: %4").arg(barcode, productName, productDetail, price));
}

