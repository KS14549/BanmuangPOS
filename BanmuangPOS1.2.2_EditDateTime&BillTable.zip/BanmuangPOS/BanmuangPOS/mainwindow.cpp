#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CartModel.h"
#include "PriceDelegate.h"
#include "QuantityDelegate.h"
#include "PaymentDialog.h"

#include <QInputDialog>
#include <QDateTime>
#include <QStandardPaths>
#include <QDir>
#include <QPrinter>
#include <QProcess>
#include <QTextFrame>
#include <QTextTable>
#include <QPainter>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , tableModel(new QStandardItemModel(this))
    , cartModel(new CartModel(this))
    , BMdatabase("Banmuang.db")
    , updatingCart(false)
{
    ui->setupUi(this);
    this->resize(1366,768);
    this->showNormal();

    // === Menu Bar ===
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);

    QMenu *menuActions = menuBar->addMenu(tr("เมนู"));
    QAction *actionAddProductToCart = menuActions->addAction(tr("เพิ่มสินค้าลงตระกร้า"));
    QAction *actionShowCost = menuActions->addAction(tr("แสดงราคา"));
    QAction *actionHideCost = menuActions->addAction(tr("ไม่แสดงราคา"));
    QAction *actionUpdateCostPrice = menuActions->addAction(tr("อัปเดตราคาต้นทุน"));
    QAction *actionUpdateSellingPrice = menuActions->addAction(tr("อัปเดตราคาขาย"));
    QAction *actionCustomerID = menuActions->addAction(tr("ระบุรหัสลูกค้า (จัดส่ง)"));
    QAction *actionPayment = menuActions->addAction(tr("ชำระเงิน"));


    // Connect actions
    connect(actionAddProductToCart, &QAction::triggered, this, &MainWindow::addProductToCartByName);
    connect(actionShowCost, &QAction::triggered, this, [this]() {
        ui->tableView->showColumn(4);  // Show Cost Price
    });
    connect(actionHideCost, &QAction::triggered, this, [this]() {
        ui->tableView->hideColumn(4);  // Hide Cost Price
    });
    connect(actionUpdateCostPrice, &QAction::triggered, this, &MainWindow::updateCostPrice);
    connect(actionUpdateSellingPrice, &QAction::triggered, this, &MainWindow::updateSellingPrice);
    connect(actionCustomerID, &QAction::triggered, this, &MainWindow::setCustomerID);
    connect(actionPayment, &QAction::triggered, this, &MainWindow::on_actionPayment_triggered);


    actionAddProductToCart->setShortcut(QKeySequence(Qt::Key_F1));
    actionShowCost->setShortcut(QKeySequence(Qt::Key_F3));
    actionHideCost->setShortcut(QKeySequence(Qt::Key_F4));
    actionUpdateCostPrice->setShortcut(QKeySequence(Qt::Key_F5));
    actionUpdateSellingPrice->setShortcut(QKeySequence(Qt::Key_F6));
    actionCustomerID->setShortcut(QKeySequence(Qt::Key_F7));
    actionPayment->setShortcut(QKeySequence(Qt::Key_F8));


    connect(ui->pushButton_OK, &QPushButton::clicked, this, &MainWindow::on_actionPayment_triggered);

    // === Open Database ===
    if (!BMdatabase.openConnection()) {
        QMessageBox::critical(this, tr("Database Error"),
                              tr("ไม่สามารถเปิดฐานข้อมูล Banmuang.db ได้"));
        return;
    }
    qDebug() << "✅ Database opened successfully.";

    setupTables();
    setupCategoryButtons();
    setupDeliveryUI();

    // Load default category
    loadProducts(1);
}

MainWindow::~MainWindow() {
    BMdatabase.closeConnection();
    delete ui;
}

// === Setup Product & Cart Tables ===
void MainWindow::setupTables() {
    // === Product Table ===
    tableModel->setHorizontalHeaderLabels(
        {"รหัสบาร์โค้ด", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาต้นทุน", "ราคาขายต่อหน่วย"}
        );

    auto *table = ui->tableView;
    table->setModel(tableModel);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setAlternatingRowColors(true);
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    table->verticalHeader()->hide();
    table->hideColumn(4);

    table->setColumnWidth(0, 60);  // Barcode
    table->setColumnWidth(1, 180);  // Product Name
    table->setColumnWidth(2, 180);  // Product Detail
    table->setColumnWidth(3, 40);   // Unit
    table->setColumnWidth(4, 80);  // Cost Price
    table->setColumnWidth(5, 80);  // Selling Price
    connect(table, &QTableView::clicked, this, &MainWindow::onTableRowClicked);

    // === Cart Table ===
    cartModel->setHorizontalHeaderLabels(
        {"#", "รหัสสินค้า", "ชื่อสินค้า", "รายละเอียดสินค้า", "หน่วย", "ราคาขายต่อหน่วย", "จำนวน"}
        );

    auto *cart = ui->tableView_2;
    cart->setModel(cartModel);
    cart->setItemDelegateForColumn(5, new PriceDelegate(tableModel, this));   // price (double)
    cart->setItemDelegateForColumn(6, new QuantityDelegate(this));  // quantity (int)
    cart->setSelectionBehavior(QAbstractItemView::SelectRows);
    cart->setSelectionMode(QAbstractItemView::SingleSelection);
    cart->setAlternatingRowColors(true);
    cart->verticalHeader()->hide();
    cart->setEditTriggers(QAbstractItemView::AllEditTriggers);
    cart->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    cart->setFont(QFont("Segoe UI", 12));

    cart->setColumnWidth(0, 20);// Row number
    cart->setColumnWidth(1, 40);// Barcode
    cart->setColumnWidth(2, 180);// ProductName
    cart->setColumnWidth(3, 180);// ProcuctDetail
    cart->setColumnWidth(4, 40);// Unit
    cart->setColumnWidth(5, 80);// SellingPrice
    cart->setColumnWidth(6, 80); //QTY



    // Context Menu
    cart->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(cart, &QTableView::customContextMenuRequested,
            this, &MainWindow::onCartContextMenu);

    connect(cartModel, &QStandardItemModel::itemChanged,
            this, &MainWindow::onCartItemChanged);
}

// === Delivery UI Setup ===
void MainWindow::setupDeliveryUI() {
    ui->doubleSpinBox_deliveryFee->setEnabled(false);

    connect(ui->checkBox_delivery, &QCheckBox::toggled, this, [this](bool checked) {
        ui->doubleSpinBox_deliveryFee->setEnabled(checked);
        updateTotalPrice();
    });

    connect(ui->doubleSpinBox_deliveryFee, qOverload<double>(&QDoubleSpinBox::valueChanged),
            this, &MainWindow::updateTotalPrice);
}

// === Map Category Buttons ===
void MainWindow::setupCategoryButtons() {
    const QMap<QString, int> buttonCategoryMap = {
        {"cPushButton_1", 1}, {"cPushButton_2", 2}, {"cPushButton_3", 3},
        {"cPushButton_4", 4}, {"cPushButton_5", 5}, {"cPushButton_6", 6},
        {"cPushButton_7", 7}, {"cPushButton_8", 8}, {"cPushButton_9", 9},
        {"cPushButton_10", 10}, {"cPushButton_11", 11}, {"cPushButton_12", 12},
        {"cPushButton_13", 13}, {"cPushButton_14", 14}, {"cPushButton_15", 15},
        {"cPushButton_16", 16}, {"cPushButton_17", 17}, {"cPushButton_18", 18},
        {"cPushButton_19", 19}, {"cPushButton_20", 20}, {"cPushButton_21", 21},
        {"cPushButton_22", 22}, {"cPushButton_23", 23}, {"cPushButton_24", 24},
        {"cPushButton_25", 25}
    };

    for (auto it = buttonCategoryMap.constBegin(); it != buttonCategoryMap.constEnd(); ++it) {
        if (auto *btn = findChild<QPushButton *>(it.key())) {
            connect(btn, &QPushButton::clicked, this, [this, categoryID = it.value()] {
                loadProducts(categoryID);
            });
        } else {
            qWarning() << "⚠️ Button not found:" << it.key();
        }
    }
}

// === Load Products by Category ===
void MainWindow::loadProducts(int categoryID) {
    qDebug() << "Loading products for category ID:" << categoryID;
    const QList<Product> products = BMdatabase.getProductsByCategory("Products", categoryID);

    tableModel->removeRows(0, tableModel->rowCount());

    for (const Product &p : products) {
        QList<QStandardItem *> rowItems;
        rowItems << new QStandardItem(p.barcode)
                 << new QStandardItem(p.name)
                 << new QStandardItem(p.detail)
                 << new QStandardItem(p.unit)
                 << new QStandardItem(QString::number(p.costPrice, 'f', 2))
                 << new QStandardItem(QString::number(p.sellingPrice, 'f', 2));
        tableModel->appendRow(rowItems);
    }
}

// === Add product to cart ===
void MainWindow::onTableRowClicked(const QModelIndex &index) {
    if (!index.isValid()) return;

    const int row = index.row();
    const QString barcode = tableModel->item(row, 0)->text();
    const QString name = tableModel->item(row, 1)->text();
    const QString detail = tableModel->item(row, 2)->text();
    const QString unit = tableModel->item(row, 3)->text();
    const QString costPrice = tableModel->item(row, 4)->text();
    const QString sellingPrice = tableModel->item(row, 5)->text();

    // Check if product already exists in cart
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        if (cartModel->item(i, 1)->text() == barcode) {
            // Increase quantity safely
            int qty = cartModel->item(i, 6)->text().toInt();
            cartModel->item(i, 6)->setText(QString::number(qty + 1));
            return;
        }
    }

    // Add new row to cart
    QList<QStandardItem *> newRow = {
        new QStandardItem(QString::number(cartModel->rowCount() + 1)),
        new QStandardItem(barcode),
        new QStandardItem(name),
        new QStandardItem(detail),
        new QStandardItem(unit),
        new QStandardItem(sellingPrice),
        new QStandardItem("1")
    };
    cartModel->appendRow(newRow);
    updateTotalPrice();
}

// === Context Menu (Remove item) ===
void MainWindow::onCartContextMenu(const QPoint &pos) {
    QModelIndex index = ui->tableView_2->indexAt(pos);
    if (!index.isValid()) return;

    QMenu menu;
    QAction *removeAction = menu.addAction(tr("ลบสินค้า"));
    QAction *selected = menu.exec(ui->tableView_2->viewport()->mapToGlobal(pos));

    if (selected == removeAction) {
        cartModel->removeRow(index.row());

        // Reindex rows
        for (int i = 0; i < cartModel->rowCount(); ++i)
            cartModel->item(i, 0)->setText(QString::number(i + 1));

        updateTotalPrice();
    }
}

// === Quantity Changed (Guarded) ===
void MainWindow::onCartItemChanged(QStandardItem *item) {
    if (updatingCart || !item) return;
    if (item->column() == 5 || item->column() == 6)
        updateTotalPrice();
}

// === Calculate Total ===
double MainWindow::updateTotalPrice() {
    updatingCart = true;

    double total = 0.0;
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        if (qty < 1) {
            cartModel->item(i, 6)->setText("1");
            qty = 1;
        }
        total += price * qty;
    }

    if (ui->checkBox_delivery->isChecked()) {
        total += ui->doubleSpinBox_deliveryFee->value();
    }

    ui->label_totalPrice->setText(QString("รวมทั้งหมด: %1 บาท").arg(total, 0, 'f', 2));

    updatingCart = false;
    return total;
}

// === Update product prices in cart ===
void MainWindow::updateCostPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 4)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาต้นทุน"),
        tr("ราคาต้นทุนใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, false)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาต้นทุนได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 4)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}

void MainWindow::updateSellingPrice() {
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("ไม่มีการเลือกสินค้า"),
                             tr("กรุณาเลือกสินค้าที่ต้องการอัปเดตราคา"));
        return;
    }

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString name = tableModel->item(row, 1)->text();
    double oldPrice = tableModel->item(row, 5)->text().toDouble();

    bool ok;
    double newPrice = QInputDialog::getDouble(
        this,
        tr("อัปเดตราคาขาย"),
        tr("ราคาขายใหม่สำหรับสินค้า '%1':").arg(name),
        oldPrice, 0.0, 999999.0, 2, &ok
        );

    if (!ok) return;

    if (!BMdatabase.updatePrice(barcode, newPrice, true)) {
        QMessageBox::critical(this, tr("ผิดพลาด"),
                              tr("ไม่สามารถอัปเดตราคาขายได้"));
        return;
    }

    // ✅ Update table view immediately
    tableModel->item(row, 5)->setText(QString::number(newPrice, 'f', 2));
    QMessageBox::information(this, tr("สำเร็จ"), tr("อัปเดตราคาสินค้าสำเร็จ"));
}

// === Print Bill ===
void MainWindow::printBill(double received, double change)
{
    // QString dateTimeStr = QDateTime::currentDateTime().toString("dd/MM/yyyy HH:mm:ss");
    QString dateTimeStr = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh:mm:ss");
    QString desktopPath = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString receiptFolderPath = QDir(desktopPath).filePath("Receipt");
    QDir().mkpath(receiptFolderPath);  // ✅ auto create folder if missing

    QString posPath = QDir(receiptFolderPath).filePath(QString("Pos_%1.pdf").arg(dateTimeStr));
    QString billPath = QDir(receiptFolderPath).filePath(QString("Bill_%1.pdf").arg(dateTimeStr));
    QString notePath    = QDir(receiptFolderPath).filePath(QString("Delivery_%1.pdf").arg(dateTimeStr));

    QPrinter printerPos(QPrinter::HighResolution);
    QPrinter printerBill(QPrinter::HighResolution);
    QPrinter printerNote(QPrinter::HighResolution);

    printerPos.setOutputFormat(QPrinter::PdfFormat);
    printerBill.setOutputFormat(QPrinter::PdfFormat);
    printerNote.setOutputFormat(QPrinter::PdfFormat);

    printerPos.setOutputFileName(posPath);
    printerBill.setOutputFileName(billPath);
    printerNote.setOutputFileName(notePath);


    // printerPos.setPageSize(QPageSize(QSizeF(80, 3200), QPageSize::Millimeter));

    // Manually set the width and height in logical units
    // QSizeF pageSize(80, 300);
    // QPageSize customPageSize(pageSize, QPageSize::Millimeter);
    QPageSize posPageSize(QSizeF(80, 210), QPageSize::Millimeter);
    QPageSize billPageSize(QPageSize::A4);
    printerPos.setPageSize(posPageSize);
    printerBill.setPageSize(billPageSize);
    printerNote.setPageSize(QPageSize::A4);

    printerPos.setPageMargins(QMarginsF(2, 2, 2, 2));
    printerBill.setPageMargins(QMarginsF(10, 10, 10, 10));
    printerNote.setPageMargins(QMarginsF(10, 10, 10, 10));

    // Extract the page dimensions directly as QSizeF
    QSizeF posPageDimensions = posPageSize.size(QPageSize::Millimeter);
    qDebug() << "Printer page size (in mm): " << posPageDimensions.width() << " x " << posPageDimensions.height();
    QSizeF billPageDimensions = billPageSize.size(QPageSize::Millimeter);
    qDebug() << "printer page size (in mm); " << billPageDimensions.width() << " x " << billPageDimensions.height();



    // === Print to PDF ===
    QTextDocument docPos,docBill,docNote;

    docPos.setPageSize(posPageDimensions); // Now you can set the page size for the document if needed
    docPos.setDefaultFont(QFont("Ubuntu", 4));
    QFont baseFont("Ubuntu", 12);
    QTextCharFormat baseFmt;
    baseFmt.setFont(baseFont);
    // docBill.setPageSize(billPageDimensions);
    docBill.setDefaultFont(baseFont);
    docNote.setDefaultFont(baseFont);

    // 🔧 Prevent Thai text from vertical rendering
    QTextOption opt;
    opt.setTextDirection(Qt::LeftToRight);
    opt.setAlignment(Qt::AlignLeft);
    opt.setWrapMode(QTextOption::NoWrap);   // ❗ ป้องกันตัดคำแนวตั้ง
    docBill.setDefaultTextOption(opt);


    QTextCursor cursor(&docBill);
    // --- Global Frame Margin ---
    QTextFrameFormat frameFmt = cursor.currentFrame()->frameFormat();
    frameFmt.setMargin(7);
    cursor.currentFrame()->setFrameFormat(frameFmt);

    // --- Title ---
    QTextBlockFormat centerFmt;
    centerFmt.setAlignment(Qt::AlignHCenter);
    QTextBlockFormat rightFmt;
    rightFmt.setAlignment(Qt::AlignRight);
    QTextBlockFormat leftFmt;
    leftFmt.setAlignment(Qt::AlignLeft);

    QFont titleFont("Ubuntu", 14, QFont::Bold);
    QTextCharFormat titleFmt;
    titleFmt.setFont(titleFont);

    QTextCharFormat boldFmt;
    QFont boldFont("Ubuntu", 12, QFont::Bold);
    boldFmt.setFont(boldFont);


    QString pos,note;
    pos += "BM\n";// No leading spaces, top aligned
    note += "                                                       ใบส่งของชั่วคราว                                                       \n";
    cursor.insertBlock(centerFmt);
    cursor.insertText("ใบส่งของชั่วคราว", titleFmt);

    pos += QString("%1\n").arg(dateTimeStr);
    note += QString("%1%2\n").arg("วันที่:",100).arg(dateTimeStr,20);
    cursor.insertBlock(rightFmt);
    cursor.insertText(QDateTime::currentDateTime().toString("วันที่ yyyy-mm-dd  เวลา hh:mm:ss"), baseFmt);
    cursor.insertBlock();



    QString nameStr,emStr,phoneStr,addressStr;
    bool ok = false;
    if(ui->checkBox_delivery->isChecked() && customerIDCheck == true){
        Customer customer = BMdatabase.findCustomerByID(customerID.toInt());
        nameStr = customer.customerName;
        emStr = customer.customerEmployee;
        phoneStr = customer.customerPhone;
        addressStr = customer.customerAddress;
    }else if(ui->checkBox_delivery->isChecked()){
        nameStr = QInputDialog::getText(
            this,
            tr("ชื่อลูกค้าที่ต้องการเพิ่ม"),
            tr("กรอกชื่อลูกค้า:"),
            QLineEdit::Normal,
            "",
            &ok
        );
        phoneStr = QInputDialog::getText(
            this,
            tr("เบอร์โทรที่ต้องการเพิ่ม"),
            tr("กรอกเบอร์โทร:"),
            QLineEdit::Normal,
            "",
            &ok
        );
        addressStr = QInputDialog::getText(
            this,
            tr("ที่อยู่ที่ต้องการเพิ่ม"),
            tr("กรอกที่อยู่:"),
            QLineEdit::Normal,
            "",
            &ok
        );
    }

    // --- Customer Info ---
    cursor.insertBlock(leftFmt);
    cursor.insertText(QObject::tr("ชื่อลูกค้า: %1 %2\n").arg(nameStr).arg(emStr),baseFmt);
    cursor.insertText(QObject::tr("เบอร์โทร: %1\n").arg(phoneStr),baseFmt);
    cursor.insertText(QObject::tr("ที่อยู่: %1\n\n").arg(addressStr),baseFmt);

    note += QString("ชื่อ: %1 เบอร์โทร: %2 \n").arg(nameStr+" "+emStr,-60).arg(phoneStr,-60);
    note += QString("ที่อยู่ : %1 \n").arg(addressStr, -120);
    note += "--------------------------------------------------------------------------------------------------------------------------\n";

    // --- Table header setup ---
    QTextTableFormat tableFmt;
    tableFmt.setBorder(0.6);
    tableFmt.setBorderStyle(QTextFrameFormat::BorderStyle_Solid);
    tableFmt.setCellPadding(4);
    tableFmt.setCellSpacing(0);
    tableFmt.setHeaderRowCount(1);
    tableFmt.setAlignment(Qt::AlignHCenter);

    // ✅ ป้องกันตารางแตกบรรทัด
    QVector<QTextLength> colWidths;
    colWidths << QTextLength(QTextLength::PercentageLength, 10)  // Qty
              << QTextLength(QTextLength::PercentageLength, 10)  // Unit
              << QTextLength(QTextLength::PercentageLength, 50)  // Product
              << QTextLength(QTextLength::PercentageLength, 15)  // Price
              << QTextLength(QTextLength::PercentageLength, 15); // Total
    tableFmt.setColumnWidthConstraints(colWidths);


    // --- Create table ---
    QTextTable *table = cursor.insertTable(1, 5, tableFmt);
    QStringList headers = {"จำนวน", "หน่วย", "สินค้า", "ราคาต่อหน่วย", "รวม"};

    QFont headerFont("Ubuntu", 12, QFont::Bold);
    QTextCharFormat headerFmt;
    headerFmt.setFont(headerFont);

    for (int i = 0; i < headers.size(); ++i) {
        QTextTableCell cell = table->cellAt(0, i);
        QTextCursor c = cell.firstCursorPosition();
        c.insertText(headers[i], headerFmt);
    }


    pos += "จำนวน หน่วย สินค้า ราคา/ชิ้น\n";
    pos += "-------------------------------------------------\n";
    note += QString("%1%2%3\n")
                .arg("จำนวน", -8)
                .arg("หน่วย", -8)
                .arg("สินค้า", -68);
    note += "--------------------------------------------------------------------------------------------------------------------------\n";

    // === รายการสินค้า ===
    for (int i = 0; i < cartModel->rowCount(); ++i) {
        QString name = cartModel->item(i, 2)->text();
        QString detail = cartModel->item(i, 3)->text();
        QString unit = cartModel->item(i, 4)->text();
        double price = cartModel->item(i, 5)->text().toDouble();
        int qty = cartModel->item(i, 6)->text().toInt();
        double sum = price * qty;

        QString fullName = name.trimmed();
        if (!detail.isEmpty()) fullName += " " + detail;

        // Each line: จำนวน หน่วย สินค้า รวม
        pos += QString("%1%2%3%4\n")
                    .arg(qty, -4)
                    .arg(unit, -4)
                   .arg(name.left(8)+detail.left(8),-16)
                    .arg(QString::number(price, 'f', 0), 4);
        note += QString("%1%2%3\n")
                    .arg(QString::number(qty), -8)
                    .arg(unit, -8)
                    .arg(fullName.left(68), -68);

        table->appendRows(1);
        int row = table->rows() - 1;
        table->cellAt(row, 0).firstCursorPosition().insertText(QString::number(qty));
        table->cellAt(row, 1).firstCursorPosition().insertText(unit);
        table->cellAt(row, 2).firstCursorPosition().insertText(fullName);
        table->cellAt(row, 3).firstCursorPosition().insertText(QString::number(price, 'f', 2));
        table->cellAt(row, 4).firstCursorPosition().insertText(QString::number(sum, 'f', 2));
    }

    pos += "-------------------------------------------------\n";
    note += "--------------------------------------------------------------------------------------------------------------------------\n";
    note += "  ผู้รับสินค้า                                                                                                                 \n";
    note += "                                           (โปรดตรวจสอบจำนวนสินค้าก่อนรับของ)                                                   \n";

    // --- Summary Section (safe version) ---
    cursor.movePosition(QTextCursor::End);
    cursor.insertBlock();
    QTextTable *sumTable = cursor.insertTable(1, 2, tableFmt); // ✅ create with 1 row

    double deliveryFee = ui->doubleSpinBox_deliveryFee->value();
    double total = updateTotalPrice();
    int r = 0;

    if (ui->checkBox_delivery->isChecked()) {
        pos += QString("ค่าจัดส่ง: %1 บาท\n").arg(deliveryFee, 0, 'f', 2);

        sumTable->appendRows(1);
        sumTable->cellAt(r, 0).firstCursorPosition().insertText("ค่าจัดส่ง:");
        sumTable->cellAt(r++, 1).firstCursorPosition()
            .insertText(QString("%1 บาท").arg(QString::number(deliveryFee, 'f', 2)));
    }
    sumTable->appendRows(1);
    sumTable->cellAt(r, 0).firstCursorPosition().insertText("รวมทั้งหมด:");
    sumTable->cellAt(r++, 1).firstCursorPosition()
        .insertText(QString("%1 บาท").arg(QString::number(total, 'f', 2)));
    pos += QString("รวมทั้งหมด: %1 บาท\n").arg(total, 0, 'f', 2);
    pos += "-------------------------------------------------\n";

    if(customerIDCheck == false){
        pos += QString("รับเงิน: %1 บาท\n").arg(received, 0, 'f', 2);

        sumTable->appendRows(1);
        sumTable->cellAt(r, 0).firstCursorPosition().insertText("รับเงิน:");
        sumTable->cellAt(r++, 1).firstCursorPosition()
            .insertText(QString("%1 บาท").arg(QString::number(received, 'f', 2)));

        sumTable->appendRows(1);
        sumTable->cellAt(r, 0).firstCursorPosition().insertText("ทอนเงิน:");
        sumTable->cellAt(r++, 1).firstCursorPosition()
            .insertText(QString("%1 บาท").arg(QString::number(change, 'f', 2)));
    }

    // --- Footer ---

    cursor.movePosition(QTextCursor::End);
    cursor.insertBlock(centerFmt);
    cursor.insertText("\nขอบคุณที่อุดหนุนครับ/ค่ะ", titleFmt);

    // ✅ Important: let document height auto-fit
    // docPos.setPageSize(QSizeF(80 * printerPos.logicalDpiX() / 25.4, 300)); //The size is measured in logical pixels when painting to the screen, and in points (1/72 inch) when painting to a printer.
    docPos.setPlainText(pos);
    docNote.setPlainText(note);

    docPos.print(&printerPos);
    docBill.print(&printerBill);
    docNote.print(&printerNote);



    // ✅ Open folder automatically
    // QDesktopServices::openUrl(QUrl::fromLocalFile(receiptFolderPath));

    // ✅ Optionally print directly via CUPS
    QString printerPosName = "Printer_POS-80";
    QString printerBillName = "EPSON_L3150_Series";
    QString printerNoteName = "EPSON_L3150_Series";

    // === Direct printer calls without /bin/sh ===
    if (ui->checkBox_1->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerPosName, posPath});
        qDebug() << "Printing POS to:" << printerPosName << "Exit code:" << exitCode;
    }

    if (ui->checkBox_2->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerBillName, billPath});
        qDebug() << "Printing BILL to:" << printerBillName << "Exit code:" << exitCode;
    }

    if (ui->checkBox_3->isChecked()) {
        int exitCode = QProcess::execute("lp", {"-d", printerNoteName, notePath});
        qDebug() << "Printing NOTE to:" << printerNoteName << "Exit code:" << exitCode;
    }


    QMessageBox::information(this, tr("ใบเสร็จ"),
                             tr("พิมพ์ใบเสร็จเรียบร้อย: %1").arg(posPath));
    customerIDCheck = false;
}

// === Set Customer ID ===
void MainWindow::setCustomerID() {
    if (!ui->checkBox_delivery->isChecked()) {
        QMessageBox::warning(this, tr("ไม่สามารถระบุได้"),
                             tr("กรุณาเลือกตัวเลือก 'จัดส่ง' ก่อน"));
        return;
    }

    bool ok;
    QString id = QInputDialog::getText(this, tr("ระบุรหัสลูกค้า"),
                                       tr("รหัสลูกค้า:"), QLineEdit::Normal,
                                       customerID, &ok);
    if (ok && !id.trimmed().isEmpty()) {
        customerID = id.trimmed();
        QMessageBox::information(this, tr("สำเร็จ"),
                                 tr("ตั้งค่ารหัสลูกค้าเป็น: %1").arg(customerID));
        customerIDCheck = true;
    }
}

void MainWindow::on_actionPayment_triggered()
{
    double totalAmount = updateTotalPrice();

    if (totalAmount <= 0) {
        QMessageBox::warning(this, tr("ไม่มีสินค้า"), tr("กรุณาเพิ่มสินค้าในตะกร้าก่อนชำระเงิน"));
        return;
    }

    PaymentDialog paymentDialog(totalAmount, this);

    connect(&paymentDialog, &PaymentDialog::paymentAccepted, this,
            [this](double received, double change) {
                printBill(received, change);
            });

    if (paymentDialog.exec() == QDialog::Accepted) {
        cartModel->clear();
        ui->checkBox_delivery->setChecked(false);
        ui->doubleSpinBox_deliveryFee->setValue(0.0);
        updateTotalPrice();
    }
}

void MainWindow::addProductToCartByName()
{
    bool ok = false;
    QString productName = QInputDialog::getText(
        this,
        tr("ชื่อสินค้าที่ต้องการเพิ่ม"),
        tr("กรอกชื่อสินค้า:"),
        QLineEdit::Normal,
        "",
        &ok
        );
    Product product = BMdatabase.findProductByName(productName);

    if (product.name.isEmpty()) {
        // Product not found — ask if user wants to add manually
        QMessageBox::StandardButton reply = QMessageBox::question(
            this,
            tr("ไม่พบสินค้า"),
            tr("ไม่พบสินค้า '%1' ในฐานข้อมูล\n\nคุณต้องการเพิ่มสินค้าใหม่นี้ลงในตะกร้าหรือไม่?")
                .arg(productName),
            QMessageBox::Yes | QMessageBox::No
            );

        if (reply == QMessageBox::No)
            return;

        // Ask for selling price
        double sellingPrice = QInputDialog::getDouble(
            this,
            tr("เพิ่มราคาขาย"),
            tr("กรอกราคาขายสำหรับสินค้า '%1':").arg(productName),
            0.0, 0.0, 999999.0, 2, &ok
            );

        if (!ok) return;

        // Optionally ask for unit
        QString unit = QInputDialog::getText(
            this,
            tr("หน่วยสินค้า"),
            tr("กรอกหน่วยสำหรับสินค้า '%1' (เช่น ชิ้น, กล่อง, กิโล):").arg(productName),
            QLineEdit::Normal,
            "ชิ้น",
            &ok
            );
        if (!ok || unit.trimmed().isEmpty()) unit = "ชิ้น";

        // Add the product to cart only (not database)
        QList<QStandardItem*> newRow = {
            new QStandardItem(QString::number(cartModel->rowCount() + 1)),
            new QStandardItem("N/A"),                  // No barcode
            new QStandardItem(productName),            // Name
            new QStandardItem("*"),      // Detail
            new QStandardItem(unit),                   // Unit
            new QStandardItem(QString::number(sellingPrice, 'f', 2)),  // Price
            new QStandardItem("1")                     // Quantity
        };

        cartModel->appendRow(newRow);
        updateTotalPrice();
        return;
    }

    // ✅ Product found — add normally
    QList<QStandardItem*> newRow = {
        new QStandardItem(QString::number(cartModel->rowCount() + 1)),
        new QStandardItem(product.barcode),
        new QStandardItem(product.name),
        new QStandardItem(product.detail),
        new QStandardItem(product.unit),
        new QStandardItem(QString::number(product.sellingPrice, 'f', 2)),
        new QStandardItem("1")
    };

    cartModel->appendRow(newRow);
    updateTotalPrice();
}




