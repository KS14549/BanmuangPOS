#include "Database.h"

Database::Database(const QString &path)
    : dbPath(path)
{
    qDebug() << "Database initialized with path:" << dbPath;
}

Database::~Database() {
    closeConnection();
    qDebug() << "Database object destroyed.";
}

bool Database::openConnection() {
    if (dbPath.isEmpty()) {
        qWarning() << "❌ Database path is empty!";
        return false;
    }

    // Reuse existing connection if it exists
    if (QSqlDatabase::contains("main_connection")) {
        sqlDatabase = QSqlDatabase::database("main_connection");
        qDebug() << "Reusing existing database connection.";
    } else {
        sqlDatabase = QSqlDatabase::addDatabase("QSQLITE", "main_connection");
        sqlDatabase.setDatabaseName(dbPath);
        qDebug() << "New database connection created.";
    }

    if (!sqlDatabase.open()) {
        qWarning() << "❌ Failed to open database:" << sqlDatabase.lastError().text();
        return false;
    }

    qDebug() << "✅ Database connection opened successfully.";
    return true;
}

void Database::closeConnection() {
    if (sqlDatabase.isOpen()) {
        sqlDatabase.close();
        qDebug() << "✅ Database closed successfully.";
    }
}

bool Database::isOpen() const {
    return sqlDatabase.isOpen();
}

QList<Product> Database::getProductsByCategory(const QString &tableName, int categoryID) {
    QList<Product> productList;

    if (!isOpen()) {
        qWarning() << "❌ Database is not open!";
        return productList;
    }

    // Safer and more efficient than QSqlTableModel
    QSqlQuery query(sqlDatabase);

    QString sql = QString(
                      "SELECT product_barcode, product_name, product_detail, unit_of_measure, selling_price "
                      "FROM %1 WHERE category_id = :categoryID;"
                      ).arg(tableName);

    query.prepare(sql);
    query.bindValue(":categoryID", categoryID);

    if (!query.exec()) {
        qWarning() << "❌ Query failed:" << query.lastError().text();
        qWarning() << "SQL:" << sql;
        return productList;
    }

    while (query.next()) {
        Product p;
        p.barcode = query.value("product_barcode").toString();
        p.name = query.value("product_name").toString();
        p.detail = query.value("product_detail").toString();
        p.unit = query.value("unit_of_measure").toString();
        p.price = query.value("selling_price").toDouble();

        productList.append(p);
    }

    qDebug() << "✅ Loaded" << productList.size() << "products from category" << categoryID;
    return productList;
}
