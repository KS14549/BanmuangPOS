#ifndef DATABASE_H
#define DATABASE_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QVariant>
#include <QList>
#include <QString>
#include <QDebug>

// Define a struct for clarity and type safety
struct Product {
    QString barcode;
    QString name;
    QString detail;
    QString unit;
    double price = 0.0;
};

class Database {
public:
    explicit Database(const QString &path);
    ~Database();

    bool openConnection();
    void closeConnection();

    QList<Product> getProductsByCategory(const QString &tableName, int categoryID);
    bool isOpen() const;

private:
    QString dbPath;
    QSqlDatabase sqlDatabase;
};

#endif // DATABASE_H
