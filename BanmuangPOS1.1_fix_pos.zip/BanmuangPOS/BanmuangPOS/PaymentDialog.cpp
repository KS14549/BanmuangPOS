#include "PaymentDialog.h"
#include "ui_paymentdialog.h"


PaymentDialog::PaymentDialog(double totalAmount, QWidget *parent)
    : QDialog(parent),
    ui(new Ui::PaymentDialog),
    totalAmount(totalAmount),
    receivedAmount(0.0),
    changeAmount(0.0)
{
    ui->setupUi(this);

    // Setup initial field values
    ui->text_total->setText(QString::number(totalAmount, 'f', 2));
    ui->text_total->setReadOnly(true);
    ui->text_change->setReadOnly(true);

    // Update change when received amount changes
    connect(ui->text_received, &QLineEdit::textChanged, this, [this](const QString &text) {
        bool ok;
        double value = text.toDouble(&ok);
        if (ok) {
            receivedAmount = value;
            updateChangeDisplay();
        } else {
            ui->text_change->setText("-");
        }
    });

    // Handle "OK" button in buttonBox
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &PaymentDialog::onButtonConfirmClicked);
}

PaymentDialog::~PaymentDialog()
{
    delete ui;
}

void PaymentDialog::updateChangeDisplay()
{
    changeAmount = receivedAmount - totalAmount;
    ui->text_change->setText(QString::number(changeAmount, 'f', 2));
}

void PaymentDialog::onButtonConfirmClicked()
{
    if (receivedAmount < totalAmount) {
        QMessageBox::warning(this, tr("ยอดเงินไม่พอ"), tr("จำนวนเงินที่รับมาน้อยกว่ายอดรวม"));
        return;
    }

    // ✅ Emit signal with full data
    emit paymentAccepted(receivedAmount, changeAmount);
    accept();
}
