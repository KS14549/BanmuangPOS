#ifndef PAYMENTDIALOG_H
#define PAYMENTDIALOG_H

#include <QDialog>

namespace Ui {
class PaymentDialog;
}

class PaymentDialog : public QDialog
{
    Q_OBJECT

public:
    explicit PaymentDialog(double totalAmount, QWidget *parent = nullptr);
    ~PaymentDialog();

signals:
    void paymentAccepted(double received, double change); // ✅ Send data to MainWindow

private slots:
    void onButtonConfirmClicked();  // Handles OK button
    void updateChangeDisplay();     // Updates change field

private:
    Ui::PaymentDialog *ui;
    double totalAmount;
    double receivedAmount;
    double changeAmount;
};

#endif // PAYMENTDIALOG_H
