#ifndef PRICEDELEGATE_H
#define PRICEDELEGATE_H

#include <QStyledItemDelegate>
#include <QDoubleSpinBox>

class PriceDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit PriceDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent) {}

    QWidget *createEditor(QWidget *parent,
                          const QStyleOptionViewItem &,
                          const QModelIndex &) const override
    {
        QDoubleSpinBox *editor = new QDoubleSpinBox(parent);
        editor->setDecimals(2);
        editor->setRange(0.00, 999999.99);
        editor->setSingleStep(0.50);
        return editor;
    }

    void setEditorData(QWidget *editor, const QModelIndex &index) const override
    {
        double value = index.model()->data(index, Qt::EditRole).toDouble();
        QDoubleSpinBox *spinBox = static_cast<QDoubleSpinBox*>(editor);
        spinBox->setValue(value);
    }

    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const override
    {
        QDoubleSpinBox *spinBox = static_cast<QDoubleSpinBox*>(editor);
        spinBox->interpretText();
        model->setData(index, spinBox->value(), Qt::EditRole);
    }
};

#endif // PRICEDELEGATE_H
