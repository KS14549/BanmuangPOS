#ifndef QUANTITYDELEGATE_H
#define QUANTITYDELEGATE_H

#include <QStyledItemDelegate>
#include <QSpinBox>

class QuantityDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit QuantityDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent) {}

    QWidget *createEditor(QWidget *parent,
                          const QStyleOptionViewItem &,
                          const QModelIndex &) const override
    {
        QSpinBox *editor = new QSpinBox(parent);
        editor->setRange(0, 9999);
        editor->setSingleStep(1);
        return editor;
    }

    void setEditorData(QWidget *editor, const QModelIndex &index) const override
    {
        int value = index.model()->data(index, Qt::EditRole).toInt();
        QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
        spinBox->setValue(value);
    }

    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const override
    {
        QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
        spinBox->interpretText();
        model->setData(index, spinBox->value(), Qt::EditRole);
    }
};

#endif // QUANTITYDELEGATE_H
