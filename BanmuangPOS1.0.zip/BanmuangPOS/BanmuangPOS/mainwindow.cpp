#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , BMdatabase("Banmuang.db")//Initialize the member Database object
    , tableModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    this->showNormal(); // or showFullScreen()

        // Try to open database
    if (!BMdatabase.openConnection()) {
        QMessageBox::critical(this, "Database Error", "Failed to open Banmuang.db");
        return;
    }

    // Set font for table view
    QFont tableFont;
    tableFont.setPointSize(16);
    ui->tableView->setFont(tableFont);

    // Configure the table model headers
    tableModel->setHorizontalHeaderLabels({"Barcode", "Product Name", "Product Detail", "Selling Price"});
    ui->tableView->setModel(tableModel);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers); // Read-only
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSortingEnabled(true);

    // Auto-resize columns
    QHeaderView *header = ui->tableView->horizontalHeader();
    header->setSectionResizeMode(0, QHeaderView::ResizeToContents); // Barcode
    header->setSectionResizeMode(1, QHeaderView::Stretch);          // Product Name
    header->setSectionResizeMode(2, QHeaderView::Stretch);          // Product Detail
    header->setSectionResizeMode(3, QHeaderView::ResizeToContents); // Selling Price

    // Optional: resize row height to fit content
    ui->tableView->resizeRowsToContents();

    // Connect table click
    connect(ui->tableView, &QTableView::clicked, this, &MainWindow::onTableRowClicked);

    // Connect all category buttons to a single slot
    QStringList buttonNames = {
        "cPushButton_1", "cPushButton_2", "cPushButton_3",
        "cPushButton_4", "cPushButton_5", "cPushButton_6",
        "cPushButton_7", "cPushButton_8", "cPushButton_9",
        "cPushButton_10"
    };

    for (const QString &name : buttonNames) {
        QPushButton *btn = findChild<QPushButton *>(name);
        if (btn) {
            connect(btn, &QPushButton::clicked, this, &MainWindow::onCategoryButtonClicked);
        }
    }
}

MainWindow::~MainWindow()
{
    BMdatabase.closeConnection();
    delete ui;
}

// SLOT: Called when a category button is clicked
void MainWindow::onCategoryButtonClicked()
{
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    if (!button) return;

    // Extract the category number from the button name
    QRegularExpression re("cPushButton_(\\d+)");
    QRegularExpressionMatch match = re.match(button->objectName());

    if (match.hasMatch()) {
        QString categoryId = match.captured(1);
        BMdatabase.setCategoryID(categoryId.toInt());

        // Get product list from DB
        auto products = BMdatabase.executeDetailedQuery("Products");

        // Clear previous data
        tableModel->removeRows(0, tableModel->rowCount());
        // tableModel->setHorizontalHeaderLabels({"Barcode", "Product Name", "Product Detail", "Selling Price"});
        // tableModel->clear();

        if (products.isEmpty()) {
            qDebug() << "No products found for category ID:" << categoryId;
            return;
        }

        for (const QList<QString> &row : products) {
            QList<QStandardItem *> items;
            for (const QString &col : row) {
                items.append(new QStandardItem(col));
            }
            tableModel->appendRow(items);
        }
        // Resize rows to fit new content
        ui->tableView->resizeRowsToContents();
    }
}
void MainWindow::onTableRowClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    int row = index.row();
    QString barcode = tableModel->item(row, 0)->text();
    QString productName = tableModel->item(row, 1)->text();
    QString productDetail = tableModel->item(row, 2)->text();
    QString price = tableModel->item(row, 3)->text();

    QMessageBox::information(this, "Product Selected",QString("Barcode: %1\nName: %2\nDetail: %3\nPrice: %4").arg(barcode, productName, productDetail, price));
}

