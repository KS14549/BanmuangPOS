// PriceDelegate.h
#ifndef PRICEDELEGATE_H
#define PRICEDELEGATE_H

#include <QStyledItemDelegate>
#include <QStandardItemModel>

class PriceDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit PriceDelegate(QStandardItemModel *productModel, QObject *parent = nullptr);

    QWidget *createEditor(QWidget *parent,
                          const QStyleOptionViewItem &option,
                          const QModelIndex &index) const override;

    void setModelData(QWidget *editor,
                      QAbstractItemModel *model,
                      const QModelIndex &index) const override;

private:
    QStandardItemModel *m_productModel;
};

#endif // PRICEDELEGATE_H
